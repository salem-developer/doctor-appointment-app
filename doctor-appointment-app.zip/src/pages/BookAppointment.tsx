


import BookAppointment from "@/sections/bookingAppointment/book-appointment";

export default function Page() {
  return (
    <>
      <title>Book Appointments</title>

      < BookAppointment/>
    </>
  );
}