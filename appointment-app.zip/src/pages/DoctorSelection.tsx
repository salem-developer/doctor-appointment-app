

import { DoctorSelection } from "@/sections/doctorList";

export default function Page() {
  return (
    <>
      <title>Doctors List</title>

      < DoctorSelection/>
    </>
  );
}