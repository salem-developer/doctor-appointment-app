
import ShowAppointment from "@/sections/appointmentList/appointment-list";

export default function Page() {
  return (
    <>
      <title>Appointments Lists</title>

      < ShowAppointment/>
    </>
  );
}